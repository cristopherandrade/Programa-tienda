/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package datos;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class Conexion {
    // Datos de tu base de datos
    private static final String URL = "jdbc:mysql://localhost:3306/tienda_db";
    private static final String USER = "root"; 
    private static final String PASS = "123456789"; // Pon tu contraseña aquí si tienes

    public static Connection conectar() {
        Connection con = null;
        try {
            // Cargar el driver (el que descargamos en el paso 2)
            Class.forName("com.mysql.cj.jdbc.Driver");
            con = DriverManager.getConnection(URL, USER, PASS);
            System.out.println("¡Conexión Exitosa!");
        } catch (ClassNotFoundException | SQLException e) {
            System.out.println("Error de conexión: " + e.getMessage());
        }
        return con;
    }
}

/*-- 1. Crear la base de datos
CREATE DATABASE tienda_db;
USE tienda_db;

-- 2. Crear la tabla de productos
CREATE TABLE productos (
    codigo VARCHAR(20) PRIMARY KEY,
    nombre VARCHAR(100) NOT NULL,
    precio DECIMAL(10,2) NOT NULL,
    stock INT NOT NULL
);

-- 3. Insertar un producto de prueba para ver si funciona luego
INSERT INTO productos VALUES ('P01', 'Soda 500ml', 1.50, 10);
ALTER TABLE productos MODIFY precio DECIMAL(10,2);*/
USE tienda_db;
-- Insertar 20 productos de prueba
INSERT INTO productos (codigo, nombre, precio, stock) VALUES
('P001', 'Arroz Premium 1kg', 1.50, 20),
('P002', 'Aceite de Girasol 1L', 3.25, 15),
('P003', 'Leche Entera 1L', 0.95, 4), -- STOCK BAJO
('P004', 'Atun en Conserva', 1.10, 30),
('P005', 'Pasta Dental 100ml', 2.45, 12),
('P006', 'Jabon de Tocador', 0.85, 3),  -- STOCK BAJO
('P007', 'Detergente en Polvo 3kg', 7.50, 8),
('P008', 'Cafe Instantaneo 200g', 5.20, 10),
('P009', 'Azucar Blanca 1kg', 1.15, 2),  -- STOCK BAJO
('P010', 'Galletas de Sal', 0.60, 50),
('P011', 'Refresco Cola 2L', 2.10, 18),
('P012', 'Papel Higienico 4 rollos', 1.80, 25),
('P013', 'Shampoo Anticaspa', 4.75, 6),
('P014', 'Cereal de Maiz', 3.90, 4),     -- STOCK BAJO
('P015', 'Mermelada de Fresa', 2.30, 9),
('P016', 'Pan de Molde', 1.65, 14),
('P017', 'Mantequilla 250g', 1.95, 2),  -- STOCK BAJO
('P018', 'Harina de Trigo 1kg', 0.80, 22),
('P019', 'Yogurt de Frutas 1L', 2.40, 11),
('P020', 'Sal Marina 500g', 0.55, 40);